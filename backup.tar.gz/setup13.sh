#!/bin/sh
export CONFIG_URI="https://raw.github.ibm.com/ptitzler/fyre-setups/master/kfdefs/kfctl_ibm_argo.v1.3.0.yaml?token=AAAB74FZ3AJAJQ43OI2M663A4R246"
minikube delete
rm -rf ~/kubeflow
minikube start --vm-driver=none
mkdir -p ~/kubeflow && cd ~/kubeflow
~/kfctl apply -V -f ${CONFIG_URI} && sleep 2m
kubectl patch svc minio-service -p '{"spec": {"type": "NodePort"}}' -n kubeflow
kubectl get service minio-service -n kubeflow
echo KFP : $(hostname):31380/pipeline
echo MinIO: $(hostname):$(kubectl get svc minio-service -n kubeflow -o jsonpath='{.spec.ports[].nodePort}')

