#!/bin/sh
set -x
if [ $# -eq 0 ]; then HOST="localhost"; PORT="8080"; else HOST="$1"; PORT="$2";fi
        STATE=$(curl -s http://${HOST}:${PORT} | grep -oP '(?<=state=)[^ ]*"' | cut -d \" -f1)
        REQ=$(curl -s "http://${HOST}:${PORT}/dex/auth?client_id=kubeflow-oidc-authservice&redirect_uri=%2Flogin%2Foidc&response_type=code&scope=profile+email+groups+openid&amp;state=$STATE" | grep -oP '(?<=req=)\w+')
        curl -s "http://${HOST}:${PORT}/dex/auth/local?req=$REQ" -H 'Content-Type: application/x-www-form-urlencoded' --data 'login=user%40example.com&password=12341234'
        CODE=$(curl -s "http://${HOST}:${PORT}/dex/approval?req=$REQ" | grep -oP '(?<=code=)\w+')
        curl -s --cookie-jar - "http://${HOST}:${PORT}/login/oidc?code=$CODE&amp;state=$STATE" > .dex_session
#        echo $(cat .dex_session | grep 'authservice_session' | awk '{print $NF}')
SESSION=$(cat .dex_session | grep 'authservice_session' | awk '{print $NF}')

echo $SERVICE_HOSTNAME
echo $MODEL_NAME
echo $INPUT_PATH

curl -v -H 'Cookie: authservice_session=$SESSION' -H "Host: ${SERVICE_HOSTNAME}" http://${INGRESS_HOST}:${INGRESS_PORT}/v1/models/$MODEL_NAME:predict -d $INPUT_PATH
