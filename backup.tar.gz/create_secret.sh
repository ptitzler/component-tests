kubectl create secret docker-registry my-secret --docker-server=https://index.docker.io/v1/ --docker-username=ptitzler --docker-password=temp4now --docker-email=ptitzler@us.ibm.com

